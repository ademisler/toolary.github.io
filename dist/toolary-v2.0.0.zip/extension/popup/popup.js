const SUPPORTED_LANGUAGES = ['en', 'tr', 'fr'];
const FAVORITES_STORAGE_KEY = 'toolaryFavorites';
const HIDDEN_STORAGE_KEY = 'toolaryHiddenTools';
const RECENT_STORAGE_KEY = 'toolaryRecentTools';
const LEGACY_FAVORITES_KEYS = ['pickachuFavorites', 'favorites'];
const LEGACY_HIDDEN_KEYS = ['pickachuHiddenTools', 'hiddenTools'];
const LEGACY_RECENT_KEYS = ['pickachuRecentTools', 'recentTools'];
const RECENT_LIMIT = 5;

const themeMediaQuery = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

const coreModulesPromise = Promise.all([
  import(chrome.runtime.getURL('core/toolRegistry.js')),
  import(chrome.runtime.getURL('core/messageRouter.js'))
]).then(([toolRegistry, messageRouter]) => ({
  toolRegistry,
  messageRouter
})).catch((error) => {
  console.error('Toolary popup: failed to load core modules', error);
  throw error;
});

const uiComponentsPromise = import(chrome.runtime.getURL('shared/ui-components.js')).catch((error) => {
  console.error('Toolary popup: failed to load UI components', error);
  throw error;
});

const state = {
  isInitialized: false,
  toolMetadata: [],
  toolMap: new Map(),
  favorites: new Set(),
  hiddenTools: new Set(),
  recents: [],
  searchTerm: '',
  activeCategory: 'all',
  langMap: {},
  loading: true
};

const elements = {};
const grids = {};
const modules = {};
const ui = {};

let shortcutsOverlay = null;
let currentThemeSetting = 'system';
let keyboardShortcuts = {};
let pendingHidden = new Set();

function dedupeStringList(list = []) {
  return Array.from(
    new Set(
      (Array.isArray(list) ? list : [])
        .map((value) => (typeof value === 'string' ? value.trim() : ''))
        .filter(Boolean)
    )
  );
}

function resolveStoredList(data, primaryKey, legacyKeys = []) {
  const current = dedupeStringList(data?.[primaryKey]);
  if (current.length > 0) {
    return { list: current, migratedFrom: null };
  }

  for (const legacyKey of legacyKeys) {
    const legacyList = dedupeStringList(data?.[legacyKey]);
    if (legacyList.length > 0) {
      return { list: legacyList, migratedFrom: legacyKey };
    }
  }

  return { list: [], migratedFrom: null };
}

function resolveLanguage(code = 'en') {
  const normalized = String(code || 'en').trim().toLowerCase();
  if (!normalized) return 'en';
  if (SUPPORTED_LANGUAGES.includes(normalized)) return normalized;
  const base = normalized.split('-')[0];
  return SUPPORTED_LANGUAGES.includes(base) ? base : 'en';
}

async function loadLang(lang) {
  const resolved = resolveLanguage(lang);
  const candidates = [...new Set([resolved, resolveLanguage(resolved), 'en'])];

  for (const candidate of candidates) {
    try {
      const res = await fetch(chrome.runtime.getURL(`_locales/${candidate}/messages.json`));
      if (res.ok) {
        return res.json();
      }
    } catch (error) {
      console.error(`Error loading language ${candidate}:`, error);
    }
  }

  return {};
}

function applyLang(map) {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = map[el.dataset.i18n]?.message || el.textContent;
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    el.title = map[el.dataset.i18nTitle]?.message || el.title;
  });
}

function getEffectiveTheme(theme) {
  if (theme === 'light' || theme === 'dark') return theme;
  return themeMediaQuery && themeMediaQuery.matches ? 'dark' : 'light';
}

function applyTheme(theme) {
  currentThemeSetting = theme;
  const effective = getEffectiveTheme(theme);
  document.body.classList.remove('light', 'dark');
  document.body.classList.add(effective === 'dark' ? 'dark' : 'light');
}

function updateVersionBadge() {
  try {
    const badge = document.getElementById('version-badge');
    if (!badge || !chrome?.runtime?.getManifest) return;
    const manifest = chrome.runtime.getManifest();
    if (manifest?.version) {
      badge.textContent = `v${manifest.version}`;
    }
  } catch (error) {
    console.debug('Toolary popup: unable to update version badge', error);
  }
}

if (themeMediaQuery) {
  const handleThemeChange = () => {
    if (currentThemeSetting === 'system') {
      applyTheme('system');
    }
  };

  if (typeof themeMediaQuery.addEventListener === 'function') {
    themeMediaQuery.addEventListener('change', handleThemeChange);
  } else if (typeof themeMediaQuery.addListener === 'function') {
    themeMediaQuery.addListener(handleThemeChange);
  }
}

function cacheElements() {
  Object.assign(elements, {
    langSelect: document.getElementById('lang-select'),
    themeSelect: document.getElementById('theme-select'),
    searchInput: document.getElementById('tool-search'),
    clearSearch: document.getElementById('clear-search'),
    categoryTabs: document.querySelector('.category-tabs'),
    resultCount: document.getElementById('result-count'),
    favoritesSection: document.getElementById('favorites-section'),
    favoritesManage: document.getElementById('manage-favorites'),
    recentSection: document.getElementById('recent-section'),
    clearRecent: document.getElementById('clear-recent'),
    toolsSection: document.getElementById('tools-section'),
    resetFilters: document.getElementById('reset-filters'),
    loadingState: document.getElementById('tools-loading'),
    emptyState: document.getElementById('empty-state'),
    favoritesFooterBtn: document.getElementById('favorites-btn'),
    shortcutsFooterBtn: document.getElementById('shortcuts-btn'),
    shortcutsBtn: document.getElementById('shortcuts-btn'),
    favoritesBtn: document.getElementById('favorites-btn'),
    searchHint: document.getElementById('search-hint'),
    settingsBtn: document.getElementById('settings-btn'),
    settingsPanel: document.getElementById('settings-panel'),
    settingsToolList: document.getElementById('settings-tool-list'),
    settingsClose: document.getElementById('close-settings'),
    settingsReset: document.getElementById('settings-reset'),
    settingsSave: document.getElementById('settings-save')
  });

  grids.all = new ui.VirtualizedGrid(document.querySelector('#tools-section .tools-virtual-container'), { threshold: 48, rowHeight: 112 });
  grids.favorites = new ui.VirtualizedGrid(document.querySelector('#favorites-section .tools-virtual-container'), { threshold: 24, rowHeight: 112 });
  grids.recent = new ui.VirtualizedGrid(document.querySelector('#recent-section .tools-virtual-container'), { threshold: 24, rowHeight: 112 });

  grids.all.setRenderer((tool) => createToolCardElement(tool));
  grids.favorites.setRenderer((tool) => createToolCardElement(tool));
  grids.recent.setRenderer((tool) => createToolCardElement(tool, { markRecent: true }));
}

function createToolCardElement(tool, { markRecent = false } = {}) {
  const card = ui.createToolCard(tool, {
    isFavorite: state.favorites.has(tool.id),
    isRecent: markRecent || state.recents.includes(tool.id),
    hidden: state.hiddenTools.has(tool.id) && !state.searchTerm
  });

  card.addEventListener('click', () => activateTool(tool.id));
  return card;
}

async function loadPreferences() {
  const syncKeys = [
    FAVORITES_STORAGE_KEY,
    HIDDEN_STORAGE_KEY,
    ...LEGACY_FAVORITES_KEYS,
    ...LEGACY_HIDDEN_KEYS
  ];

  const syncData = await chrome.storage.sync.get(syncKeys);
  const favorites = resolveStoredList(syncData, FAVORITES_STORAGE_KEY, LEGACY_FAVORITES_KEYS);
  const hidden = resolveStoredList(syncData, HIDDEN_STORAGE_KEY, LEGACY_HIDDEN_KEYS);

  state.favorites = new Set(favorites.list);
  state.hiddenTools = new Set(hidden.list);

  const migrationTasks = [];
  if (favorites.migratedFrom) {
    migrationTasks.push(chrome.storage.sync.set({ [FAVORITES_STORAGE_KEY]: favorites.list }));
    migrationTasks.push(chrome.storage.sync.remove(favorites.migratedFrom));
  }
  if (hidden.migratedFrom) {
    migrationTasks.push(chrome.storage.sync.set({ [HIDDEN_STORAGE_KEY]: hidden.list }));
    migrationTasks.push(chrome.storage.sync.remove(hidden.migratedFrom));
  }

  const localKeys = [RECENT_STORAGE_KEY, ...LEGACY_RECENT_KEYS];
  const localData = await chrome.storage.local.get(localKeys);
  const recents = resolveStoredList(localData, RECENT_STORAGE_KEY, LEGACY_RECENT_KEYS);
  state.recents = recents.list.slice(0, RECENT_LIMIT);

  if (recents.migratedFrom) {
    migrationTasks.push(chrome.storage.local.set({ [RECENT_STORAGE_KEY]: state.recents }));
    migrationTasks.push(chrome.storage.local.remove(recents.migratedFrom));
  }

  if (migrationTasks.length > 0) {
    Promise.allSettled(migrationTasks).catch((error) => {
      console.warn('Toolary popup: storage migration warnings', error);
    });
  }
}

async function saveFavorites() {
  await chrome.storage.sync.set({ [FAVORITES_STORAGE_KEY]: Array.from(state.favorites) });
}

async function saveHiddenTools() {
  await chrome.storage.sync.set({ [HIDDEN_STORAGE_KEY]: Array.from(state.hiddenTools) });
}

async function saveRecents() {
  await chrome.storage.local.set({ [RECENT_STORAGE_KEY]: state.recents });
}

function matchesSearch(tool, term) {
  if (!term) return true;
  const haystack = [
    tool.name,
    tool.description,
    tool.category,
    ...(tool.tags || []),
    ...(tool.keywords || [])
  ].join(' ').toLowerCase();
  return haystack.includes(term);
}

function rebuildShortcutMap(tools = []) {
  keyboardShortcuts = {};
  tools.forEach((tool) => {
    const shortcut = typeof tool.shortcut === 'object' && tool.shortcut
      ? tool.shortcut.default || tool.shortcut.mac || ''
      : tool.shortcut || '';
    if (typeof shortcut === 'string') {
      const match = shortcut.match(/([A-Za-z0-9])$/);
      if (match) {
        keyboardShortcuts[match[1]] = tool.id;
      }
    }
  });
}

function applyFilters() {
  const term = state.searchTerm.trim().toLowerCase();
  const category = state.activeCategory;

  const filtered = state.toolMetadata.filter((tool) => {
    if (category !== 'all' && tool.category !== category) {
      return false;
    }

    const hidden = state.hiddenTools.has(tool.id);
    if (!term && hidden) {
      return false;
    }

    return matchesSearch(tool, term);
  });

  state.filteredTools = filtered;
  rebuildShortcutMap(filtered);
  renderToolLists();
  updateResultCount();
  updateSectionsVisibility();
}

function renderToolLists() {
  grids.all.setData(state.filteredTools);
  grids.all.root.scrollTop = 0;

  const favoritesList = state.toolMetadata.filter(tool => state.favorites.has(tool.id));
  grids.favorites.setData(favoritesList);
  grids.favorites.root.scrollTop = 0;

  const recentList = state.recents
    .map(id => state.toolMap.get(id))
    .filter(Boolean);
  grids.recent.setData(recentList);
  grids.recent.root.scrollTop = 0;

  const empty = state.filteredTools.length === 0;
  elements.emptyState.hidden = !empty;
}

function updateResultCount() {
  const count = state.filteredTools.length;
  const label = count === 1 ? '1 tool' : `${count} tools`;
  elements.resultCount.textContent = label;
}

function updateSectionsVisibility() {
  const hasFavorites = state.favorites.size > 0;
  const hasRecents = state.recents.length > 0;

  elements.favoritesSection.hidden = !hasFavorites;
  elements.recentSection.hidden = !hasRecents;
}

function setLoadingState(isLoading) {
  state.loading = isLoading;
  elements.loadingState.hidden = !isLoading;
}

function updateSearchHint() {
  if (!elements.searchHint) return;
  elements.searchHint.textContent = state.searchTerm
    ? `${state.filteredTools.length} matches`
    : 'Press / to focus';
}

function updateFooterButtons(map) {
  const favoritesLabel = map?.favorites?.message || 'Favorites';
  const favoritesBtn = elements.favoritesBtn;
  if (favoritesBtn) {
    favoritesBtn.setAttribute('aria-label', favoritesLabel);
    const textSpan = favoritesBtn.querySelector('.footer-btn-text');
    if (textSpan) {
      textSpan.textContent = favoritesLabel;
    }
  }

  const shortcutsLabel = map?.shortcuts?.message || 'Shortcuts';
  const shortcutsBtn = elements.shortcutsBtn;
  if (shortcutsBtn) {
    shortcutsBtn.setAttribute('aria-label', shortcutsLabel);
    const textSpan = shortcutsBtn.querySelector('.footer-btn-text');
    if (textSpan) {
      textSpan.textContent = shortcutsLabel;
    }
  }
}

function toggleFavorite(toolId) {
  if (!toolId) return;
  if (state.favorites.has(toolId)) {
    state.favorites.delete(toolId);
    ui.showToast('Removed from favorites', 'info');
  } else {
    state.favorites.add(toolId);
    ui.showToast('Added to favorites', 'success');
  }
  saveFavorites();
  renderToolLists();
  updateSectionsVisibility();
}

function recordRecent(toolId) {
  const index = state.recents.indexOf(toolId);
  if (index !== -1) {
    state.recents.splice(index, 1);
  }
  state.recents.unshift(toolId);
  if (state.recents.length > RECENT_LIMIT) {
    state.recents.length = RECENT_LIMIT;
  }
  saveRecents();
  renderToolLists();
  updateSectionsVisibility();
}

async function activateTool(toolId) {
  try {
    const tool = state.toolMap.get(toolId);
    const { messageRouter } = modules;
    await messageRouter.sendRuntimeMessage(messageRouter.MESSAGE_TYPES.ACTIVATE_TOOL, { toolId });
    recordRecent(toolId);
    if (tool) {
      ui.showToast(`${tool.name} activated`, 'success');
    }
    setTimeout(() => window.close(), 80);
  } catch (error) {
    console.error('Toolary popup: failed to activate tool', error);
    ui.showToast('Failed to activate tool', 'error');
  }
}

function handleToolContainerClick(event) {
  const favoriteButton = event.target.closest('.favorite-toggle');
  if (favoriteButton) {
    return;
  }
  const card = event.target.closest('.tool-card');
  if (!card) return;
  activateTool(card.dataset.toolId);
}

function handleFavoriteToggle(event) {
  const button = event.target.closest('.favorite-toggle');
  if (!button) return;
  event.preventDefault();
  event.stopPropagation();
  toggleFavorite(button.dataset.toolId);
}

function attachContainerListeners() {
  document.querySelectorAll('.tools-virtual-container').forEach((container) => {
    container.addEventListener('click', handleToolContainerClick);
    container.addEventListener('click', handleFavoriteToggle, true);
  });
}

function handleSearchInput(event) {
  state.searchTerm = event.target.value;
  updateSearchHint();
  applyFilters();
}

function handleCategoryClick(event) {
  const tab = event.target.closest('.category-tab');
  if (!tab) return;
  if (tab.dataset.category === state.activeCategory) return;
  document.querySelectorAll('.category-tab').forEach(btn => {
    btn.classList.toggle('is-active', btn === tab);
    btn.setAttribute('aria-selected', btn === tab ? 'true' : 'false');
  });
  state.activeCategory = tab.dataset.category;
  applyFilters();
}

function resetFilters() {
  state.searchTerm = '';
  state.activeCategory = 'all';
  elements.searchInput.value = '';
  document.querySelectorAll('.category-tab').forEach(btn => {
    const active = btn.dataset.category === 'all';
    btn.classList.toggle('is-active', active);
    btn.setAttribute('aria-selected', active ? 'true' : 'false');
  });
  applyFilters();
  updateSearchHint();
}

function focusSection(section) {
  const target = section === 'favorites'
    ? elements.favoritesSection
    : section === 'recent'
      ? elements.recentSection
      : elements.toolsSection;
  if (!target || target.hidden) return;
  target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  const firstCard = target.querySelector('.tool-card');
  if (firstCard) {
    setTimeout(() => firstCard.focus(), 200);
  }
}

function clearRecentTools() {
  state.recents = [];
  saveRecents();
  renderToolLists();
  updateSectionsVisibility();
  ui.showToast('Recent tools cleared', 'info');
}

function handleKeyboardNavigation(event) {
  const activeElement = document.activeElement;
  if (event.key === '/' && !['INPUT', 'TEXTAREA'].includes(activeElement.tagName)) {
    event.preventDefault();
    elements.searchInput.focus();
    elements.searchInput.select();
    return;
  }

  if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) {
    const card = activeElement?.closest('.tool-card');
    if (!card) return;
    event.preventDefault();
    const container = card.closest('.tools-grid');
    if (!container) return;
    const cards = Array.from(container.querySelectorAll('.tool-card'));
    const index = cards.indexOf(card);
    if (index === -1) return;
    const columns = Math.max(1, Math.round(container.clientWidth / (cards[0]?.offsetWidth || 180)));
    let nextIndex = index;
    switch (event.key) {
      case 'ArrowRight':
        nextIndex = Math.min(cards.length - 1, index + 1);
        break;
      case 'ArrowLeft':
        nextIndex = Math.max(0, index - 1);
        break;
      case 'ArrowDown':
        nextIndex = Math.min(cards.length - 1, index + columns);
        break;
      case 'ArrowUp':
        nextIndex = Math.max(0, index - columns);
        break;
      default:
        break;
    }
    cards[nextIndex]?.focus();
  }
}

function renderSettingsList() {
  const container = elements.settingsToolList;
  if (!container) return;
  container.innerHTML = '';

  state.toolMetadata.forEach((tool) => {
    const item = document.createElement('div');
    item.className = 'settings-tool-item';

    const label = document.createElement('div');
    label.className = 'settings-tool-item__label';
    label.innerHTML = `<span>${tool.name}</span><span>${tool.category}</span>`;

    const toggle = document.createElement('input');
    toggle.type = 'checkbox';
    toggle.className = 'toggle';
    toggle.dataset.toolId = tool.id;
    toggle.checked = !pendingHidden.has(tool.id);

    toggle.addEventListener('change', () => {
      if (toggle.checked) {
        pendingHidden.delete(tool.id);
      } else {
        pendingHidden.add(tool.id);
      }
    });

    item.append(label, toggle);
    container.appendChild(item);
  });
}

function openSettingsPanel() {
  pendingHidden = new Set(state.hiddenTools);
  renderSettingsList();
  elements.settingsPanel.hidden = false;
  elements.settingsPanel.classList.add('is-open');
  elements.settingsBtn.setAttribute('aria-expanded', 'true');
  setTimeout(() => {
    const firstToggle = elements.settingsPanel.querySelector('.toggle');
    firstToggle?.focus();
  }, 60);
}

function closeSettingsPanel({ save = false } = {}) {
  if (save) {
    state.hiddenTools = new Set(pendingHidden);
    saveHiddenTools();
    applyFilters();
  }
  elements.settingsPanel.classList.remove('is-open');
  elements.settingsPanel.hidden = true;
  elements.settingsBtn.setAttribute('aria-expanded', 'false');
  elements.settingsBtn.focus();
}

function resetSettings() {
  pendingHidden = new Set();
  renderSettingsList();
}

function updateFavoritesAccessibility(map) {
  const manageLabel = map?.manageFavorites?.message || 'Manage favorites';
  if (elements.favoritesManage) {
    elements.favoritesManage.textContent = manageLabel;
  }
}

function showShortcutsModal(map = state.langMap) {
  closeShortcutsModal();

  const overlay = document.createElement('div');
  overlay.id = 'popup-shortcuts-overlay';
  overlay.className = 'modal-overlay';

  const modal = document.createElement('div');
  modal.className = 'modal';

  const header = document.createElement('div');
  header.className = 'modal-header';

  const title = document.createElement('div');
  title.className = 'modal-title';
  title.textContent = map?.shortcutsTitle?.message || 'Keyboard shortcuts';

  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.className = 'modal-close';
  closeBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>';

  header.appendChild(title);
  header.appendChild(closeBtn);

  const body = document.createElement('div');
  body.className = 'modal-body';

  const descriptionText = map?.shortcutsDescription?.message || 'Trigger Toolary faster with these shortcuts.';
  const description = document.createElement('p');
  description.className = 'modal-description';
  description.textContent = descriptionText;
  body.appendChild(description);

  const shortcutsList = [
    { label: map?.shortcutOpen?.message || map?.openToolary?.message || 'Open Toolary', key: 'Ctrl+Shift+9' },
    { label: map?.shortcutToggle?.message || 'Toggle popup', key: 'Ctrl+Shift+P' },
    { label: map?.shortcutClose?.message || 'Close popup', key: 'Esc' }
  ];

  state.toolMetadata.forEach((tool) => {
    const shortcut = typeof tool.shortcut === 'object' && tool.shortcut
      ? tool.shortcut.default || tool.shortcut.mac || ''
      : tool.shortcut || '';
    if (!shortcut) return;
    shortcutsList.push({ label: tool.name, key: shortcut });
  });

  const shortcutsSection = document.createElement('div');
  shortcutsSection.style.cssText = 'display:flex;flex-direction:column;gap:8px;';

  shortcutsList.forEach(({ label, key }) => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:rgba(0,0,0,0.03);border-radius:8px;font-size:13px;';

    const labelEl = document.createElement('span');
    labelEl.textContent = label;
    labelEl.style.cssText = 'color:var(--toolary-text);font-weight:500;';

    const keyEl = document.createElement('span');
    keyEl.textContent = key;
    keyEl.style.cssText = 'background:var(--toolary-button-bg);border:1px solid var(--toolary-border);padding:4px 8px;border-radius:6px;font-size:11px;font-weight:600;color:var(--toolary-text);font-family:monospace;';

    row.append(labelEl, keyEl);
    shortcutsSection.appendChild(row);
  });

  body.appendChild(shortcutsSection);

  modal.append(header, body);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  const handleOverlayClick = (event) => {
    if (event.target === overlay) {
      closeShortcutsModal();
    }
  };

  closeBtn.addEventListener('click', closeShortcutsModal);
  overlay.addEventListener('click', handleOverlayClick);

  shortcutsOverlay = overlay;
}

function closeShortcutsModal() {
  if (shortcutsOverlay) {
    shortcutsOverlay.remove();
    shortcutsOverlay = null;
  }
}

async function initializeLanguageAndTheme() {
  const stored = await chrome.storage.local.get(['language', 'theme']);
  let lang = stored?.language ? resolveLanguage(stored.language) : null;
  if (!lang) {
    const autoLang = resolveLanguage(chrome.i18n?.getUILanguage?.() || navigator.language || 'en');
    lang = autoLang;
    await chrome.storage.local.set({ language: lang });
  }

  let theme = stored?.theme;
  if (!['light', 'dark', 'system'].includes(theme)) {
    theme = 'system';
    await chrome.storage.local.set({ theme });
  }

  state.langMap = await loadLang(lang);
  applyLang(state.langMap);
  updateFooterButtons(state.langMap);
  updateFavoritesAccessibility(state.langMap);

  if (elements.langSelect) {
    elements.langSelect.value = SUPPORTED_LANGUAGES.includes(lang) ? lang : 'en';
  }
  if (elements.themeSelect) {
    elements.themeSelect.value = theme;
  }
  applyTheme(theme);
}

async function loadToolMetadata() {
  setLoadingState(true);
  const { toolRegistry } = modules;
  state.toolMetadata = await toolRegistry.getAllTools();
  state.toolMap = new Map(state.toolMetadata.map(tool => [tool.id, tool]));
  setLoadingState(false);
  applyFilters();
  renderSettingsList();
}

function attachEventListeners() {
  elements.searchInput?.addEventListener('input', handleSearchInput);
  elements.clearSearch?.addEventListener('click', () => {
    elements.searchInput.value = '';
    state.searchTerm = '';
    updateSearchHint();
    applyFilters();
  });

  elements.categoryTabs?.addEventListener('click', handleCategoryClick);
  elements.resetFilters?.addEventListener('click', resetFilters);
  elements.clearRecent?.addEventListener('click', clearRecentTools);

  elements.favoritesFooterBtn?.addEventListener('click', () => focusSection('favorites'));
  elements.favoritesManage?.addEventListener('click', openSettingsPanel);
  elements.shortcutsFooterBtn?.addEventListener('click', () => showShortcutsModal());

  elements.langSelect?.addEventListener('change', async (event) => {
    const newLang = resolveLanguage(event.target.value);
    event.target.value = newLang;
    await chrome.storage.local.set({ language: newLang });
    state.langMap = await loadLang(newLang);
    applyLang(state.langMap);
    updateFooterButtons(state.langMap);
    updateFavoritesAccessibility(state.langMap);
    applyFilters();
  });

  elements.themeSelect?.addEventListener('change', async (event) => {
    const requested = event.target.value;
    const normalized = ['light', 'dark', 'system'].includes(requested) ? requested : 'system';
    event.target.value = normalized;
    await chrome.storage.local.set({ theme: normalized });
    applyTheme(normalized);
  });

  elements.settingsBtn?.addEventListener('click', openSettingsPanel);
  elements.settingsClose?.addEventListener('click', () => closeSettingsPanel({ save: false }));
  elements.settingsReset?.addEventListener('click', resetSettings);
  elements.settingsSave?.addEventListener('click', () => {
    closeSettingsPanel({ save: true });
    ui.showToast('Tool visibility updated', 'success');
  });
  elements.settingsPanel?.addEventListener('click', (event) => {
    if (event.target === elements.settingsPanel) {
      closeSettingsPanel({ save: false });
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      if (shortcutsOverlay) {
        event.preventDefault();
        closeShortcutsModal();
        return;
      }
      if (!elements.settingsPanel.hidden) {
        event.preventDefault();
        closeSettingsPanel({ save: false });
        return;
      }
      window.close();
    }
  });

  document.addEventListener('keydown', handleKeyboardNavigation);
}

document.addEventListener('DOMContentLoaded', async () => {
  if (state.isInitialized) return;
  state.isInitialized = true;

  const [{ toolRegistry, messageRouter }, uiModule] = await Promise.all([
    coreModulesPromise,
    uiComponentsPromise
  ]);
  Object.assign(modules, { toolRegistry, messageRouter });
  Object.assign(ui, uiModule);

  cacheElements();
  updateVersionBadge();
  attachContainerListeners();
  attachEventListeners();

  await initializeLanguageAndTheme();
  await loadPreferences();
  await loadToolMetadata();
  updateSearchHint();
  renderToolLists();
});
