// Simple script to create PNG icons from SVG
// This creates a data URL that can be used to generate PNG files

import fs from 'fs';

// Create SVG content with popup theme colors
const createSVG = (size) => {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="#00BFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <rect x="3" y="3" width="7" height="7" fill="#00BFFF" fill-opacity="0.15"/>
  <rect x="14" y="3" width="7" height="7" fill="#00BFFF" fill-opacity="0.15"/>
  <rect x="14" y="14" width="7" height="7" fill="#00BFFF" fill-opacity="0.15"/>
  <rect x="3" y="14" width="7" height="7" fill="#00BFFF" fill-opacity="0.15"/>
</svg>`;
};

// Create HTML file for manual conversion
const htmlContent = `<!DOCTYPE html>
<html>
<head>
    <title>Toolary Icons</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f8f9fa; }
        .icon { margin: 20px; display: inline-block; }
        canvas { border: 1px solid #ddd; }
    </style>
</head>
<body>
    <h1>Toolary Layout Grid Icons</h1>
    <p>Right-click on each canvas and "Save image as" to download the PNG files.</p>
    
    <div class="icon">
        <h3>16x16</h3>
        <canvas id="icon16" width="16" height="16"></canvas>
    </div>
    
    <div class="icon">
        <h3>48x48</h3>
        <canvas id="icon48" width="48" height="48"></canvas>
    </div>
    
    <div class="icon">
        <h3>128x128</h3>
        <canvas id="icon128" width="128" height="128"></canvas>
    </div>

    <script>
        function drawIcon(canvas, size) {
            const ctx = canvas.getContext('2d');
            const scale = size / 24;
            
            // Clear canvas
            ctx.clearRect(0, 0, size, size);
            
            // Set colors
            ctx.strokeStyle = '#00BFFF';
            ctx.fillStyle = '#00BFFF';
            ctx.lineWidth = 2 * scale;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            
            // Draw grid
            const rects = [
                {x: 3, y: 3, w: 7, h: 7},
                {x: 14, y: 3, w: 7, h: 7},
                {x: 14, y: 14, w: 7, h: 7},
                {x: 3, y: 14, w: 7, h: 7}
            ];
            
            rects.forEach(rect => {
                // Fill with light blue
                ctx.globalAlpha = 0.15;
                ctx.fillRect(rect.x * scale, rect.y * scale, rect.w * scale, rect.h * scale);
                
                // Stroke with blue
                ctx.globalAlpha = 1;
                ctx.strokeRect(rect.x * scale, rect.y * scale, rect.w * scale, rect.h * scale);
            });
        }
        
        // Draw all icons
        drawIcon(document.getElementById('icon16'), 16);
        drawIcon(document.getElementById('icon48'), 48);
        drawIcon(document.getElementById('icon128'), 128);
    </script>
</body>
</html>`;

// Write the HTML file
fs.writeFileSync('generate-icons-canvas.html', htmlContent);

console.log('Created generate-icons-canvas.html');
console.log('Open this file in a browser and right-click on each canvas to save as PNG files.');
console.log('Save them as icon16.png, icon48.png, and icon128.png respectively.');
